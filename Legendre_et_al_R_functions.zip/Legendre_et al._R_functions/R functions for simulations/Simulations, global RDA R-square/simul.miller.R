'run.simul.miller' <-
   function(param, nruns=2, ierr=1, sd.max=1, scaleY=TRUE, perm=FALSE)
# This function carries out simulations for a whole file of parameters 'param'.
# The function 'simul.miller' carries out the simulations for each line 
# in the file of parameters.
# Parameters:

# Use of this function: simul.out = run.simul.miller(param, nruns=2)
#
# License: GPL-2. Author: Pierre Legendre
{
library(vegan)
a <- system.time({
out = rep(0,9)
for(ir in 1:nruns) {
   cat("Run #",ir,'\n')
   res = simul.miller(param$nsim[ir], param$nperm[ir], param$n[ir], param$p[ir], param$m[ir], ierr=ierr, sd.max=sd.max, scaleY=scaleY, perm=perm)
   line.out = c(param[ir,1:5], ierr, scaleY, res$rate.1, res$rate.2)
   out = rbind(out,line.out)
   }
})
a[3] <- sprintf("%2f",a[3])
cat("Total simulation time =",a[3]," sec",'\n')
#
out = out[-1,]   
colnames(out)=c("nsim","nperm","n","p","m","ierr","scaleY","rate.Miller","rate.Permute")
rownames(out)=rownames(1:nruns, do.NULL = FALSE, prefix = "out.")
class(out) = "run.simul"
out
}

# ========

'simul.miller' <-
   function(nsim=1, nperm=99, n=10, p=1, m=1, ierr=1, sd.max=1, scaleY=NULL, perm=FALSE, verbose=FALSE)
# Simulations: estimate the rate of type I error of Miller (1975) F-test in RDA.
# Verify that Miller's parametric test works when the response data are 
# standardized by columns. 
#
# Parameters of the program
#    nsim = number of simulated pairs of data tables
#    nperm = number of permutations
#    n = number of simulated objects
#    p // In type I error study: p = number of variables in Y
#         In power study: p = pp*block (computed by the program)
#    m // In type I error study: m = number of variables in X
#         In power study: m =  2*block (computed by the program)
#    ierr = type of error: 1 = N(0,1) : rnorm(n)
#                          2 = Exp    : exp(n)
#                          3 = Exp**3 : exp(n)^3
#    sd.max = maximum standard deviation (randomly chosen) for columns of Y
#    scaleY=TRUE: standardize the Y variables
#    perm=TRUE: conduct permutation test (vegan)
#    verbose: print results of each simulation
#
# Example of use for test of type I error: 
#    result = simul.miller(nsim=1, nperm=99, n=20, p=5, m=5, ierr=1, scaleY=TRUE, perm=TRUE)
#
# License: GPL-2. Author: Pierre Legendre
{
a <- system.time({
alpha = 0.05
rate.1 = 0
rate.2 = 0
#
for(kk in 1:nsim) {
	temp = generate.YX(n=n, p=p, m=m, ierr=ierr, sd.max=sd.max)
	X.mat = scale(temp$X.mat, center=TRUE, scale=TRUE)
	Y.mat = scale(temp$Y.mat, center=TRUE, scale=scaleY)
	Y.hat = predict(lm(Y.mat ~ X.mat))
	R2 = sum(Y.hat^2)/sum(Y.mat^2)
	df1 = m*p
	df2 = (n-m-1)*p
	Fstat = (R2*df2) / ((1-R2)*df1)
	p.par = pf(Fstat,df1,df2,lower.tail=FALSE)
	if(p.par <= alpha) rate.1 = rate.1 + 1
	if(perm) {
		rda.out = rda(Y.mat, X.mat)
		p.perm = anova(rda.out, step=nperm+1, perm.max=nperm+1)[1,5]
		if(p.perm <= alpha) rate.2 = rate.2 + 1
		}
	}
#
})
a[3] <- sprintf("%2f",a[3])
cat("Simulation time, Miller =",a[3]," sec",'\n')
cat('\n')
#
out = list(rate.1=rate.1/nsim, rate.2=rate.2/nsim)
class(out) = "simul.test.eigval"
out
}

# ========

`generate.YX` <- 
   function(n=10, p=1, m=1, ierr=1, sd.max=1)
# Data generation for simulations for tests of type I error in RDA.
# The columns of Y are from linearly independent statistical populations.
# Use of this function: test.generate.YX = generate.YX(20,5,2,1)
#
# License: GPL-2. Author: Pierre Legendre
{
	X.mat <<- matrix(rnorm(n*m),n,m)
	if(ierr == 1) {
		err.vec = rnorm(n*p)
		} else if(ierr == 2) {
		err.vec = rexp(n*p)
		} else {
		err.vec = (rexp(n*p))^3
		}

	sd = runif(p,1,sd.max)  # Vector of unequal standard deviations
	if(p > 1) {
		Y.mat <<- matrix(err.vec,n,p) %*% diag(sd)
		} else {
		Y.mat = as.matrix(err.vec,n,1)
		}
#
parameters = c(n,p,m,ierr)
out = list(simul.param=parameters, Y.mat=Y.mat, X.mat=X.mat)
out
}

# ========
