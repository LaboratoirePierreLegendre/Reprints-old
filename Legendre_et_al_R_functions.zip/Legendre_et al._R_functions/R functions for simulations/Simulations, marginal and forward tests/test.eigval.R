`test.eigval` <-
    function(Y.mat, X.mat, nperm = 1000, direct=FALSE, verbose=FALSE, ...)
#
# Test of individual eigenvalues in two ways, using vegan's 'rda' function:
# => Testing procedure 'jari': marginal test.
# => Testing procedure 'cajo': forward test.
#
# There is no allowance for a file of external covariables in this function.
#
# License: GPL-2. Author: Pierre Legendre
{
#   a <- system.time({
#
# if(class(Y.mat)=="data.frame") cat("test.eigval - Y.mat is a data.frame",'\n')
# if(class(X.mat)=="data.frame") cat("test.eigval - X.mat is a data.frame",'\n')
    
    if(direct) {
       model = "direct"
       } else {
       model = "reduced"
       }
#
    ## Jari's method, available in vegan
    totoJ = rda(Y.mat ~ ., data=X.mat)
    rnk <- totoJ$CCA$rank
    toto.anova = anova(totoJ, step=(nperm+1), perm.max=(nperm+1), model=model, by="axis")
    # 999 random perm. plus the real value is called 1000 perm. in anova.cca
    jariF = toto.anova[1:rnk,3]
    pval.jari = toto.anova[1:rnk,5]

    ## Cajo's method using forward.test(), which is not compiled
    totoC = forward.test(Y.mat, X.mat, nperm=nperm)
    cajoF = totoC[,2]
    pval.cajo = totoC[,3]
    if(length(pval.cajo) < rnk) rnk = length(pval.cajo)
#
#     })
#     a[3] <- sprintf("%2f",a[3])
#     cat("Computation time, cajoaxes4JC =",a[3]," sec",'\n')
#
out <- list(jariF=jariF, pval.jari = pval.jari, cajoF=cajoF, pval.cajo = pval.cajo, howmany = rnk)
    class(out) <- "test.eigval"
    out
}
