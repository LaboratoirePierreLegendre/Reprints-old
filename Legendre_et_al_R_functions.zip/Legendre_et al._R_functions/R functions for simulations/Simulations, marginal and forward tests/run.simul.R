`run.simul` <-
   function(param, nruns=2, ierr=1, direct=FALSE)
# This function carries out simulations for a whole file of parameters 'param'.
# The function 'simul.test.eigval' carries out the simulations for each 
# line of parameters.
#
# Parameters of the function
#    param = name of the file containing the 8 simulation parameters
#    nruns = number of rows of that file that should be used for the run
#    ierr = type of error: 1 = N(0,1) : rnorm(n)
#                          2 = Exp    : exp(n)
#                          3 = Exp**3 : exp(n)^3
#    direct = TRUE : permute raw data
#           = FALSE: permute residuals of reduced model
#
# outJ = results of Jari Oksanen's 'marginal' test
# outC = results of Cajo ter Braak's 'forward' test
#
# License: GPL-2. Author: Pierre Legendre
{
library(vegan)
   a <- system.time({
outJ <<- rep(0,17)
outC <<- rep(0,17)
# Use a line of parameters (file 'param') for each simulation run
for(ir in 1:nruns) {
   if(param$block[ir] == 0) {
      no.ax = min(param$p[ir], param$m[ir])
      } else {
      no.ax = min(2,param$pp[ir])*param$block[ir]
      }
   cat("Run #",ir,"  No. axes =",no.ax,'\n')
   #
   # Call the function that does the calculations
   res = simul.test.eigval(param$nsim[ir], param$nperm[ir], param$n[ir], param$p[ir], param$m[ir], param$block[ir], param$pp[ir], param$beta.err[ir], ierr=ierr, direct=direct)
   #
   # Recuperate the results
   ouJ = c(param[ir,1:8],no.ax)
   ouC = c(param[ir,1:8],no.ax)
   vecJ = res$rate[1,]
   vecC = res$rate[2,]
   ouJ = c(ouJ,vecJ,rep(NA,(8-length(vecJ))))   # 8 = number of axes tested
   ouC = c(ouC,vecC,rep(NA,(8-length(vecC))))   # 8 = number of axes tested
   outJ <<- rbind(outJ,ouJ)
   outC <<- rbind(outC,ouC)
   write.table(outJ, file="outJ.txt")
   write.table(outC, file="outC.txt")
   }
     })
     a[3] <- sprintf("%2f",a[3])
     cat('\n')
     cat("Total simulation time =",a[3]," sec",'\n')
#
outJ <<- outJ[-1,]
outC <<- outC[-1,]
rownames(outJ)=rownames(1:nruns, do.NULL = FALSE, prefix = "outJ.")
colnames(outJ)=c("nsim","nperm","n","p","m","bl","pp","beta.err","no.ax","Ax1","Ax2","Ax3","Ax4","Ax5","Ax6","Ax7","Ax8")
rownames(outC)=rownames(1:nruns, do.NULL = FALSE, prefix = "outC.")
colnames(outC)=c("nsim","nperm","n","p","m","bl","pp","beta.err","no.ax","Ax1","Ax2","Ax3","Ax4","Ax5","Ax6","Ax7","Ax8")
outt = list(outJ=outJ, outC=outC)
class(outt) = "run.simul"
   write.table(outJ, file="outJ.txt")
   write.table(outC, file="outC.txt")
outt
}
