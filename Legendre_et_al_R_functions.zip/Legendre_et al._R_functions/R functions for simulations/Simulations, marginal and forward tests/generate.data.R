`generate.data` <- 
   function(n=10, p=1, m=1, block=0, pp=1, beta.err=0.2, ierr=1)
# Data generation for simulations for tests of canonical eigenvalues.
# Use of this function: test.generate.data = generate.data(20,3,2,1,3,0.2,1)
#
# License: GPL-2. Author: Pierre Legendre
   {
   if(block>0) {   # Create relationships between blocks of Y and blocks of X
      # cat("block =",block,'\n')
      p = pp*block
      m =  2*block
      X.mat <<- matrix(rnorm(n*m),n,m)
      Y.mat <<- matrix(NA,n,p)
      x1 = 0
      y1 = 0
      for(bb in 1:block) {
         x1 = x1+1
         x2 = x1+1
         for(cc in 1:pp) {
            y1 = y1+1
             if(ierr == 1) {
               err.vec = rnorm(n)
               } else if(ierr == 2) {
               err.vec = rexp(n)
               } else {
               err.vec = (rexp(n))^3
               }
           Y.mat[,y1] <<- 0.5*X.mat[,x1] + 0.5*X.mat[,x2] + beta.err*err.vec
            }
         }

      } else {       # No relationship between Y and X 
      X.mat <<- matrix(rnorm(n*m),n,m)
      if(ierr == 1) {
         err.vec = rnorm(n*p)
         } else if(ierr == 2) {
         err.vec = rexp(n*p)
         } else {
         err.vec = (rexp(n*p))^3
         }
      Y.mat <<- matrix(err.vec,n,p)
      }
# cat("nrow(Y.mat) =",nrow(Y.mat)," ncol(Y.mat) =",ncol(Y.mat),'\n')
# cat("nrow(X.mat) =",nrow(X.mat)," ncol(X.mat) =",ncol(X.mat),'\n')

Y.mat <<- as.data.frame(Y.mat)
X.mat <<- as.data.frame(X.mat)
# if(class(Y.mat)=="data.frame") cat("Y.mat is a data.frame",'\n')
# if(class(X.mat)=="data.frame") cat("X.mat is a data.frame",'\n')

parameters = c(n,p,m,block,pp,beta.err,ierr)
out = list(simul.param=parameters, Y.mat=Y.mat, X.mat=X.mat)
out
}
