`simul.test.eigval` <- 
   function(nsim=1, nperm=99, n=10, p=1, m=1, block=0, pp=1, 
            beta.err=0.2, ierr=1, direct=FALSE, verbose=FALSE)
#
# Comparison of two tests of significance of the eigenvalues in RDA.
#    “Jari” refers to Jari Oksanen’s marginal testing method.
#    “Cajo” refers to Cajo ter Braak’s forward testing method .
# Testing is done by the function ' test.eigval.R' 
#
# Parameters of the function
#    nsim = number of simulated pairs of data tables
#    nperm = number of permutations
#    n = number of simulated objects
#    p // In type I error study: p = number of variables in Y
#         In power study: p = pp*block (computed by the program)
#    m // In type I error study: m = number of variables in X
#         In power study: m =  2*block (computed by the program)
#    block = number of blocks of Y correlated to X variables (max=2)
#    pp = number of Y variables correlated to X in each block
#    beta.err = importance of random error component in the power study
#    ierr = type of error: 1 = N(0,1) : rnorm(n)
#                          2 = Exp    : exp(n)
#                          3 = Exp**3 : exp(n)^3
#    direct = TRUE : permute raw data
#           = FALSE: permute residuals of reduced model
#    verbose: print results of each simulation
#
# Ex. test of type I error: 
#    simul.canoco.typeI = simul.test.eigval(10,99,100,3,3,verbose=TRUE)
#    simul.canoco.typeI = simul.test.eigval(1000,99,20,3,3,verbose=FALSE)
# Ex. simulations for power:
#    simul.canoco.power = simul.test.eigval(1000,99,20,0,0,1,3)
#
# License: GPL-2. Author: Pierre Legendre
{
   a <- system.time({
#
if(verbose & (nsim>20)) stop("Too many simulations for 'verbose' output",'\n')
alpha = 0.05
if(block>0) {
   p = pp*block
   m =  2*block
   }
max.eigval = min(p,m)
rate.jari = rep(0, max.eigval)
rate.cajo = rep(0, max.eigval)
nsimul.howmany = rep(0, max.eigval)
#
for(kk in 1:nsim) {

temp = generate.data(n=n,p=p,m=m,block=block,pp=pp,beta.err=beta.err,ierr=ierr)
X.mat = temp$X.mat
Y.mat = temp$Y.mat
# if(class(Y.mat)=="data.frame") cat("simul.test.eigval - Y.mat is a data.frame",'\n')
# if(class(X.mat)=="data.frame") cat("simul.test.eigval - X.mat is a data.frame",'\n')
#
if(verbose) {
   rda.out = rda(Y.mat, X.mat)
   toto = anova(rda.out, step=nperm, perm.max=nperm)
   cat("Simulation no.",kk,"  Overall F =",toto[1,3],"  p-value =",toto[1,5], '\n')
   # cat("can.eigenval =",summary(rda.out)$ev.con,'\n')
   }
res = test.eigval(Y.mat, X.mat, nperm=nperm, direct=direct)

# Check that the simulated data produce the expected number of canonical 
# eigenvalues in both jari ( rda() ) and cajo ( forward.test() ). These two 
# functions have different tolerances for eigenvalues near zero.
howmany = res$howmany
if(howmany < max.eigval) cat("Simulation #",kk,"  Howmany positive eigenvalues =",howmany,'\n')
for(kk in 1:howmany) nsimul.howmany[kk] = nsimul.howmany[kk]+1
#
if(verbose) {
   cat("pval.jari =",res$pval.jari,'\n')
   cat("pval.cajo =",res$pval.cajo,'\n','\n')
   }
#
for(j in 1:howmany) {
   if(res$pval.jari[j] <= alpha) rate.jari[j] = rate.jari[j]+1
   if(res$pval.cajo[j] <= alpha) rate.cajo[j] = rate.cajo[j]+1
   }
}
cat("nsimul.howmany =",nsimul.howmany,'\n')
rate.jari = rate.jari/nsimul.howmany
rate.cajo = rate.cajo/nsimul.howmany
#
rate = rbind(rate.jari,rate.cajo)
     })
     a[3] <- sprintf("%2f",a[3])
     cat("Simulation time =",a[3]," sec",'\n')
#
parameters = c(nsim,nperm,n,p,m,block,pp)
out = list(simul.param=parameters, rate=rate)
class(out) = "simul.test.eigval"
out
}
