`simul.test.eigval.simultaneous` <- 
   function(nsim=1, nperm=99, n=10, p=1, m=1, block=0, pp=1, ierr=1, verbose=FALSE)
#
# Simulations comparing two test statistics, F1 and F2, for the simultaneous 
# method for tests of significance of individual eigenvalues in RDA.
#
# Parameters of the program
#    nsim = number of simulated pairs of data tables
#    nperm = number of permutations
#    n = number of simulated objects
#    p // In type I error study: p = number of variables in Y
#         In power study: p = pp*block (computed by the program)
#    m // In type I error study: m = number of variables in X
#         In power study: m =  2*block (computed by the program)
#    block = number of blocks of Y correlated to X variables (max=2)
#    pp = number of Y variables correlated to X in each block
#    ierr = type of error: 1 = N(0,1) : rnorm(n)
#                          2 = Exp    : exp(n)
#                          3 = Exp**3 : exp(n)^3
#    verbose: print results of each simulation
#
# Example of use for test of type I error: 
#    result = simul.test.eigval.simultaneous(10,99,20,3,3,0,0,verbose=TRUE)
#
# License: GPL-2. Author: Pierre Legendre
{
   a <- system.time({
#
if(verbose & (nsim>20)) stop("Too many simulations for 'verbose' output",'\n')
alpha = 0.05
if(block>0) {
   p = pp*block
   m =  2*block
   }
max.eigval = min(p,m)
rate.jari = rep(0, max.eigval)
rate.cajo = rep(0, max.eigval)
nsimul.howmany = rep(0, max.eigval)
eigval = numeric(max.eigval)
F.ref1 = numeric(max.eigval)
F.ref2 = numeric(max.eigval)
F.perm1 = numeric(max.eigval)
F.perm2 = numeric(max.eigval)
rate.1 = rep(0, max.eigval)
rate.2 = rep(0, max.eigval)
nsimul.howmany = rep(0, max.eigval)
if(verbose) {
   cat("rate.1 =",rate.1,'\n')
   cat("rate.2 =",rate.2,'\n','\n')
   }
#
for(kk in 1:nsim) {
temp = generate.data(n=n, p=p, m=m, block=block, pp=pp, beta.err=0.2, ierr=ierr)
X.mat = temp$X.mat
Y.mat = temp$Y.mat
#
nGE1 = rep(1,max.eigval)
nGE2 = rep(1,max.eigval)
prob.F.1 = numeric(max.eigval)
prob.F.2 = numeric(max.eigval)
rda.out = rda(Y.mat, X.mat)
if(verbose) {
   toto = anova(rda.out, step=nperm, perm.max=nperm)
   cat("Simulation no.",kk,"  Overall F =",toto[1,3],"  p-value =",toto[1,5],'\n')
   }
sum.var = summary(rda.out)$tot.chi
rnk = rda.out$CCA$rank
if(rnk < max.eigval) cat("Simulation #",kk,"  Howmany canonical eigenvalues =",rnk,'\n')
for(j in 1:rnk) nsimul.howmany[j] = nsimul.howmany[j]+1
eigval = rda.out$CCA$eig
sum.all.eigval = summary(rda.out)$constr.chi
sum.eigval = 0
for(j in 1:rnk) {   # Canoco 4 manual, p. 49. Canoco 4.5 manual, p. 51.
   sum.eigval = sum.eigval+eigval[j]
   F.ref1[j] = eigval[j]*(n-1-m-j) / (sum.var-sum.eigval)
   F.ref2[j] = eigval[j]*(n-1-m-rnk) / (sum.var-sum.all.eigval)
   }
nb.perm = 0
for(iperm in 1:nperm) {

   Y.perm = Y.mat[sample(n),]
   out.perm = rda(Y.perm, X.mat)
   rnk.perm = out.perm$CCA$rank
   if(rnk.perm == rnk) {   # Eliminate permutation if rnk.perm < rnk
      nb.perm = nb.perm+1
      eigval = out.perm$CCA$eig
      sum.all.eigval = summary(out.perm)$constr.chi
      sum.eigval = 0
      for(j in 1:rnk) {   # Canoco 4 manual, p. 49
         sum.eigval = sum.eigval+eigval[j]
         F.perm1[j] = eigval[j]*(n-1-m-j) / (sum.var-sum.eigval)
         F.perm2[j] = eigval[j]*(n-1-m-rnk) / (sum.var-sum.all.eigval)
         }
      }
#
   for(j in 1:rnk) {
      if(F.perm1[j] >= F.ref1[j]) nGE1[j] = nGE1[j]+1
      if(F.perm2[j] >= F.ref2[j]) nGE2[j] = nGE2[j]+1
      }
   }
#
for(j in 1:rnk) {
   prob.F.1[j] = nGE1[j]/(nb.perm+1)
   prob.F.2[j] = nGE2[j]/(nb.perm+1)
   }
#
if(verbose) {
   cat("prob.F.1 =",prob.F.1,'\n')
   cat("prob.F.2 =",prob.F.2,'\n','\n')
   }
#
for(j in 1:max.eigval) {
   if(prob.F.1[j] <= alpha) rate.1[j] = rate.1[j]+1
   if(prob.F.2[j] <= alpha) rate.2[j] = rate.2[j]+1
   }
}

cat("nsimul.howmany =",nsimul.howmany,'\n')
rate.1 = rate.1/nsimul.howmany
rate.2 = rate.2/nsimul.howmany
#
     })
     a[3] <- sprintf("%2f",a[3])
     cat("Simulation time, Simultaneous =",a[3]," sec",'\n')
#
parameters = c(nsim,nperm,n,p,m,block,pp)
out = list(simul.param=parameters, rate.1=rate.1, rate.2=rate.2)
class(out) = "simul.test.eigval"
out
}
