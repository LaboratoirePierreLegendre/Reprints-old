`run.simul.simultaneous` <-
   function(param, nruns=2, ierr=1)
# This function carries out simulations for a whole file of parameters 'param'.
# The function 'simul.test.eigval.simultaneous' carries out the simulations 
# for each line in the file of parameters.
#
# License: GPL-2. Author: Pierre Legendre
{
library(vegan)
   a <- system.time({
outF1 = rep(0,16)
outF2 = rep(0,16)
for(ir in 1:nruns) {
   if(param$block[ir] == 0) {
      no.ax = min(param$p[ir], param$m[ir])
      } else {
      no.ax = min(2,param$pp[ir])*param$block[ir]
      }
   cat("Run #",ir,"  No. axes =",no.ax,'\n')
   res = simul.test.eigval.simultaneous(param$nsim[ir], param$nperm[ir], param$n[ir], param$p[ir], param$m[ir], param$block[ir], param$pp[ir], ierr=ierr)
   #
   par = c(param[ir,1:7],no.ax)
   vecF1 = res$rate.1
   vecF2 = res$rate.2
   ouF1 = c(par,vecF1,rep(NA,(8-length(vecF1))))   # 8 = number of axes tested
   ouF2 = c(par,vecF2,rep(NA,(8-length(vecF2))))   # 8 = number of axes tested
   outF1 = rbind(outF1,ouF1)
   outF2 = rbind(outF2,ouF2)
   }
     })
     a[3] <- sprintf("%2f",a[3])
     cat('\n')
     cat("Total simulation time =",a[3]," sec",'\n')
outF1 = outF1[-1,]
outF2 = outF2[-1,]
rownames(outF1)=rownames(outF2)=rownames(1:nruns, do.NULL = FALSE, prefix = "out.")
colnames(outF1)=colnames(outF2)=c("nsim","nperm","n","p","m","bl","pp","no.ax","Ax1","Ax2","Ax3","Ax4","Ax5","Ax6","Ax7","Ax8")
out = list(F1=outF1, F2=outF2)
class(out) = "run.simul"
out
}
