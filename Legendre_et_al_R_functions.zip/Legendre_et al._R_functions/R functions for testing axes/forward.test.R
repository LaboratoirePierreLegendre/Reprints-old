'forward.test' <-
   function(Y, X, nperm=199, seed=NULL, scaleY=FALSE, verbose=FALSE)
#
# Test of canonical eigenvalues in simple RDA using the forward method.
# In this method, the residual SS in the denominator of F differs from axis 
# to axis: it is the residual SS of the regression of Y on canonical axes 
# from 1 to the one being tested. 
#
# This is a simple explicit program, without shortcuts nor compiled
# permutation function. Its aim is to unambiguously describe the stepwise
# testing method. The code is interspersed with comments to explain the
# computation steps. This function is not intended for routine testing of 
# canonical eigenvalues, although it produces correct, publishable results.
# 
# Parameters:
#    Y: response data matrix
#    X: explanatory data matrix
#    nperm: number of permutations
#    seed: seed for random number generator, used by the permutation function 
#          sample(). If seed=NULL (default), a random integer is drawn as the 
#          seed for the run. It will be reset to that value before the test of 
#          each canonical axis. All axes are thus tested using the same set of 
#          permutations. A fixed value, e.g. seed=12345, can be givenn by the 
#          user to compare the results of this function with that of other 
#          functions where the seed can also be set at run time.
#    scaleY = TRUE : standardize the Y variables
#           = FALSE: the Y variables are centered on their means
#    verbose = TRUE: print intermediate F and F.perm results
#
# License: GPL-2 
# Authors: Pierre Legendre, Cajo J. F. ter Braak and Jari Oksanen, 2010
{
   if(nperm > 5) verbose <- FALSE   # Modify this limit as needed #
   if(length(seed)==0) seed <- ceiling(runif(1,max=10000))
   cat("seed =",seed,'\n')
   a <- system.time({               # How much time needed for the test?
   epsilon <- sqrt(.Machine$double.eps)
#
# Center or standardize the Y variables, standardize the X variables
   Y <- scale(as.matrix(Y), center=TRUE, scale=scaleY)
   X <- scale(as.matrix(X), center=TRUE, scale=TRUE)
   n <- nrow(Y)
   SS.Y <- sum(Y^2)
#
# Compute the rank of X
   m <- sum(svd(X, nv = 0, nu = 0)$d^2 > epsilon)
#
# RDA consists of 2 steps: regression, done with QR to avoid overhead of lm(), 
# then PCA of the table of fitted values by decomposition of the matrix of 
# Sums of Squares and Cross Products (SSCP), which is the same as cov*(n-1).
   Q <- qr(X)                      # We use QR decomposition for efficiency
   Yhat <- qr.fitted(Q, Y)         # Faster than: Yhat<-fitted.values(lm(Y~X))
   SS.Yhat <- sum(Yhat^2)
   Yhat.eig <- svd(Yhat, nv=0)     # svd decomposition of Yhat
   eig.values <- Yhat.eig$d^2      # = eigen(cov( t(Yhat)%*%Yhat ))$values
   k <- sum(eig.values > epsilon)  # Number of canonical eigenvalues
   axes <- Yhat.eig$u[,1:k]        # Canonical axes = f(X)
#
# A section could be added here to compute the RDA R-square (SS.Yhat/SS.Y) 
# and test its significance (F-test).
# A section could be added here to produce a biplot with scaling type 1 or 2.
#
# Test the significance of individual canonical axes
   #
   # Test of axis 1: no residuals to be computed on previously tested axes
   # No covariables: test canonical axis 1 by permutation of the raw data.
   F <- eig.values[1] / (SS.Y - eig.values[1])
   Fstat <- F*(n-1-m)        # Start assembling vector 'Fstat'
   sum.eigval <- eig.values[1]
   #
   set.seed(seed)
   nGE <- 1   # Hope correction: count 'Fstat' in the reference distribution
   for(iperm in 1:nperm) {
      Y.perm <- Y[sample(n),]
      SS.Y.perm <- SS.Y      # Same SS for Y and Y.perm after permuting Y rows
      # Re-use the QR decomposition of X: does not change in permutations
      Yhat.perm <- qr.fitted(Q, Y.perm)
      Yhat.perm.eig <- svd(Yhat.perm, nv=0, nu=0)$d^2
      eig.value.perm <- Yhat.perm.eig[1]
      #
      F.perm <- eig.value.perm / (SS.Y.perm - eig.value.perm)
      if(F.perm >= F) nGE <- nGE+1
      if(verbose) cat("Axis 1   :   F =",F,"  F.perm =",F.perm,'\n')
      }
   prob <- nGE/(nperm+1)     # Start assembling vector 'prob'
   
   # Test the following canonical axes by permuting residuals of reduced model
   if(k > 1) {
   for(j in 2:k) {
      sum.eigval <- sum.eigval + eig.values[j]
      F <- eig.values[j] / (SS.Y - sum.eigval)
      Fstat <- c(Fstat, F*(n-1-m))   # Attach the new F value to 'Fstat'
      #
      # Compute reduced model residuals of Y on the previously tested axes
      qr.prev  <- qr(axes[,1:(j-1)])
      Y.fit <- qr.fitted(qr.prev, Y)
      Y.res <- qr.resid(qr.prev, Y)
      qr.X.res <- qr(qr.resid(qr.prev, X))

      set.seed(seed)
      nGE <- 1   # Hope correction
      if(verbose) cat('\n')
      for(iperm in 1:nperm) {
         # Create permuted Y and compute its sum of squares (SS)
         Y.perm <- Y.fit + Y.res[sample(n),]
         SS.Y.perm <- sum(Y.perm^2)   # Not same SS as in the unpermuted data
         #
         # The j-th eigenvalue is the first eigenvalue of the partial RDA
         # of Y.perm by X in the presence of the previous axes[,1:(j-1)].
         # Prior to the permutation loop, X has been residualized on the 
         # previous axes.
         Yhat.perm <- qr.fitted(qr.X.res, Y.perm)
         Yhat.perm.eig1 <- svd(Yhat.perm, nv=0, nu=0)$d[1]^2
         #
         # The fitted values of Y.perm on the previous axes [1:(j-1)]
         # provide the first [1:(j-1)] constrained eigenvalues for the 
         # denominator of F. We sum them, then we add the j-th eigenvalue 
         # 'Yhat.perm.eig1' computed above.
         sum.eig.1toj.perm <- sum(qr.fitted(qr.prev, Y.perm)^2)+Yhat.perm.eig1
         #
         # Compute the F-statistic under permutation for the tested eigenvalue
         F.perm <- Yhat.perm.eig1 / (SS.Y.perm - sum.eig.1toj.perm)
         if(F.perm >= F) nGE <- nGE+1
         if(verbose) cat("Axis [",j,"]:  F =",F,"  F.perm =",F.perm,'\n')
         }
      prob <- c(prob, nGE/(nperm+1))   # Attach the new probability to 'prob'
      }
      }
#
  })
  a[3] <- sprintf("%2f",a[3])
  cat("Computation time =",a[3]," sec",'\n')
#
# Output the results.
# The eigenvalues of the covariance matrix = (eigenvalues computed here)/(n-1)
out <- cbind(eig.values[1:k]/(n-1), Fstat, prob)
#
rownames(out) <- rownames(out, do.NULL=FALSE, prefix="Axis.")	
colnames(out) <- c("Eigenvalue", "F.forward", "P.forward")
out
}
