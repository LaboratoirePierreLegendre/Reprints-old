'test.axes.canoco'<-
   function(Y, X, W=NULL, nperm=199, seed=NULL, scaleY=FALSE, verbose=FALSE)
#
# Test of canonical eigenvalues in simple or partial RDA using the marginal and
# forward methods. The function uses permutation of residuals of the reduced 
# model (Freedman & Lane, 1983).
#
# In the forward method, the residual SS in the denominator of F differs from 
# axis to axis: it is the residual SS of the regression of Y on canonical axes 
# 1 to the one being tested. 
#
# This is a simple explicit program, without shortcuts nor compiled
# permutation function. Its aim is to unambiguously describe the stepwise
# testing method in the presence of a matrix of covariables W. 
# The code is interspersed with comments to explain the computation steps. 
# This function is not intended for routine testing of canonical eigenvalues, 
# although it produces correct, publishable results.
# 
# Parameters:
#    Y: response data matrix
#    X: explanatory data matrix
#    W: matrix of covariables
#    nperm: number of permutations
#    seed: seed for random number generator, used by the permutation function 
#          sample(). If seed=NULL (default), a random integer is drawn as the 
#          seed for the run. It will be reset to that value before the test of 
#          each canonical axis. All axes are thus tested using the same set of 
#          permutations. A fixed value, e.g. seed=12345, can be givenn by the 
#          user to compare the results of this function with that of other 
#          functions where the seed can also be set at run time.
#    scaleY = TRUE : standardize the Y variables
#           = FALSE: center the Y variables on their means
#    verbose = TRUE: print messages and intermediate F and F.perm results
#
# License: GPL-2 
# Authors: Cajo J. F. ter Braak, Jari Oksanen and Pierre Legendre, 2010
{
   if(nperm > 5) verbose <- FALSE   # Modify this limit as needed #
##
## BEGIN: Internal functions
##
my.pRDA<-function(Y, X, W, epsilon) 
   {
   # In this function, partial RDA is an RDA of (residuals of Y on W) with  
   # respect to (residuals of X on W). 
   # The residalization of Y is optional, but handy since Yres.X.res allows one 
   # to directly compute the residual sum-of-squares for the denominator of 
   # the F.marginal statistic.
   #
   qr.W <- qr(W)
   Y.fit <- qr.fitted(qr.W,Y)         # Fitted values of Y on W
   Y.res <- Y-Y.fit                   # Y residualized on W
   X.res <- X - qr.fitted(qr.W,X)     # X residualized on W
   #
   # RDA consists of 2 steps: regression of Y.res on X.res, then PCA of the  
   # table of fitted values by eigen decomposition of the matrix of Sums of 
   # Squares and Cross Products (SSCP), which is equal to cov*(n-1).

   qr.X <- qr(X.res)
   Y.fit.X.res <- qr.fitted(qr.X,Y.res)  # Fitted values of Y(res|W) on X(res|W)
   Yres.X.res  <- Y.res - Y.fit.X.res    # Residuals of Y(res|W) on X(res|W)

   svd1 <- svd(Y.fit.X.res, nv=0 )
   eig.values <- svd1$d^2
   k <- sum(eig.values > epsilon)           # Number of canonical eigenvalues
   axes <- as.matrix(svd1$u[,1:k], ncol= k) # Canonical axes = f(X)

   RSS.Y.on.W <- sum(Y.res^2)               # fraction [a+d]
   RSS.Y.on.X.and.W <- sum(Yres.X.res^2)    # fraction [d]
   #
   # F-statistics (marginal and forward methods) without the constant (n-1-mq)                                                 
   Fstat.axis1.marginal <- eig.values[1] / RSS.Y.on.X.and.W
   Fstat.axis1.forward <- eig.values[1] / (RSS.Y.on.W - eig.values[1]) 
   # print( c(eig.values[1], RSS.Y.on.W - eig.values[1] ))   

   out <- list(eig.values=eig.values, axes=axes, k=k, Y.fit.X.res=Y.fit.X.res, 
   Y.fit=Y.fit, Y.res=Y.res, Fstat.axis1.forward=Fstat.axis1.forward, 
   Fstat.axis1.marginal=Fstat.axis1.marginal)
   out
   }

test.axes <- function(Y, X, W, nperm, seed, epsilon, verbose=FALSE)
   {
   # Test the canonical axes one by one by permuting residuals of reduced model
   # after fitting to ( W and the axes 1:(j-1) )
   Fstat.m <- NULL
   Fstat.f <- NULL

   prob.m <- NULL 
   prob.f <- NULL
   rda.data0 <- my.pRDA(Y,X,W,epsilon)
   k = rda.data0$k                           # Number of canonical axes
   for (j in 1:k) {
      rda.data <- my.pRDA(Y,X,W,epsilon)
      F.m <- rda.data$Fstat.axis1.marginal
      Fstat.m <- c(Fstat.m,F.m)
      F.f <- rda.data$Fstat.axis1.forward
      Fstat.f <- c(Fstat.f,F.f)
      set.seed(seed)
      nGE.m <- 1   # Hope correction
      nGE.f <- 1   # Hope correction
      if(verbose) cat('\n')
      for(iperm in 1:nperm) {
         # Create permuted Y 
         Y.fit <- rda.data$Y.fit
         Y.res <- rda.data$Y.res
         Y.perm <- Y.fit + Y.res[sample(n),]
         rda.perm <- my.pRDA(Y.perm,X,W,epsilon)
         #
         F.perm.m <- rda.perm$Fstat.axis1.marginal 
         F.perm.f <- rda.perm$Fstat.axis1.forward
         if(F.perm.m >= F.m) nGE.m <- nGE.m+1
         if(F.perm.f >= F.f) nGE.f <- nGE.f+1
         if(verbose) cat("Axis [",j,"]:  F.m =",F.m,"  F.perm.m =",F.perm.m,
         	"  F.f =",F.f,"  F.perm.f =",F.perm.f,'\n')
         }
      prob.m <- c(prob.m, nGE.m/(nperm+1))   # Attach the new value to 'prob'
      prob.f <- c(prob.f, nGE.f/(nperm+1))   # Attach the new value to 'prob'
      W <- cbind(W, rda.data$axes[,1])       # Add to W axes 1:(j-1), by steps 
      }
   out <- list(rda.data=rda.data0, Fstat=cbind(Fstat.m,Fstat.f), 
          prob=cbind(prob.m,prob.f))
   out
   }
##
## END: Internal functions
##
   if(nperm > 5) verbose <- FALSE   # Modify this limit as needed #
   if(length(seed)==0) seed <- ceiling(runif(1,max=10000))
   cat("seed =",seed,'\n')
   a <- system.time({             # How much time for the permutation test?
   epsilon <- sqrt(.Machine$double.eps)
#
# Center or standardize the Y variables, standardize the X variables
   Y <- scale(as.matrix(Y), center=TRUE, scale=scaleY)
   X <- scale(as.matrix(X), center=TRUE, scale=TRUE)
   n <- nrow(Y)

   # Find the rank of X
   m <- length(which(svd(cov(X))$d > epsilon))

# Is there a matrix W containing covariables?
   if(length(W)==0) {
      covar <- FALSE
      W <- rep(1,n)
      if(verbose) cat("\nThere is no matrix of covariables\n")
      } else {
      covar <- TRUE
      W <- scale(as.matrix(W), center=TRUE, scale=FALSE)
      if(verbose) cat("\nThere is a matrix of covariables\n")
      }
   # Compute the rank of cbind(X, W) 
   mq <- sum(svd(cov(cbind(X, W)), nv = 0, nu = 0)$d > epsilon)
   if(verbose) cat('n =',n,' m =',m,' mq =',mq,'\n')

# Test the canonical axes by permuting residuals of the reduced model

   test.out <- test.axes(Y,X,W,nperm,seed,epsilon,verbose)
   rda.data <- test.out$rda.data

})
   a[3] <- sprintf("%2f",a[3])
   cat("Computation time =",a[3]," sec",'\n')
#
# Output the results

k <- rda.data$k
eig.values <-rda.data$eig.values
 
test.out$Fstat[,1:2] = test.out$Fstat[,1:2]*(n-1-mq) 
# Divide Fstat by (n-1-mq) for compatibility with Canoco

# The eigenvalues of the covariance matrix = (eigenvalues computed here)/(n-1)
out <- cbind(eig.values[1:k]/(n-1), test.out$Fstat, test.out$prob)
rownames(out) <- rownames(out, do.NULL=FALSE, prefix="Axis.")	
colnames(out) <- c("Eigenvalue","F-stat.m","F-stat.f","P-value.m","P-value.f")
res <- list(test.axes=out, axes=rda.data$axes)
res
}
