'marginal.test' <- 
   function(Y,X,nperm=199,seed=NULL,scaleY=FALSE,verbose=FALSE)
# 
# Test of canonical eigenvalues in simple RDA using the marginal method.
# In this method, the residual SS in the denominator of F is the same for the 
# test of all canonical axes: the residual SS of the regression of Y on X.
#
# This is a simple explicit program, without shortcuts nor compiled  
# permutation function. Its aim is to unambiguously describe the marginal 
# testing method. The code is interspersed with comments to explain the 
# computation steps. This function is not intended for routine testing of 
# canonical eigenvalues, although it produces correct, publishable results.
# 
# Parameters:
#    Y: response data matrix
#    X: explanatory data matrix; no factors are allowed
#    nperm: number of permutations
#    seed: seed for random number generator, used by the permutation function 
#          sample(). If seed=NULL (default), a random integer is drawn as the 
#          seed for the run. It will be reset to that value before the test of 
#          each canonical axis. All axes are thus tested using the same set of 
#          permutations. A fixed value, e.g. seed=12345, can be givenn by the 
#          user to compare the results of this function with that of other 
#          functions where the seed can also be set at run time.
#    scaleY = TRUE : standardize the Y variables
#           = FALSE: the Y variables are centered on their means
#    verbose = TRUE: print intermediate F and F.perm results
#
# License: GPL-2 
# Authors: Pierre Legendre and Jari Oksanen, 2010
{
   if(nperm > 5) verbose <- FALSE   # Modify this limit as needed #
   if(length(seed)==0) seed <- ceiling(runif(1,max=10000))
   cat("seed =",seed,'\n')
   a <- system.time({             # How much time needed for the test?
   epsilon <- sqrt(.Machine$double.eps)
#
# Center or standardize the Y variables, standardize the X variables
   Y <- scale(as.matrix(Y), center=TRUE, scale=scaleY)
   X <- scale(as.matrix(X), center=TRUE, scale=TRUE)
   n <- nrow(Y)
   SS.Y <- sum(Y^2)
#
# Compute the rank of X
   m <- length(which(svd(cov(X))$d > epsilon))
#
# RDA consists of 2 steps: regression, then PCA of the table of fitted 
# values by eigen decomposition of the matrix of Sums of Squares and Cross 
# Products (SSCP), which is cov*(n-1)
   qr.X <- qr(X)                   # We use QR decomposition for efficiency
   Yhat <- qr.fitted(qr.X, Y)      # Faster than: Yhat<-fitted.values(lm(Y~X))
   SS.Yhat <- sum(Yhat^2)                    
   Yhat.eig <- svd(Yhat, nv=0)     # svd decomposition of Yhat
   eig.values <- Yhat.eig$d^2      # = eigen(cov( t(Yhat)%*%Yhat ))$values
   k <- sum(eig.values > epsilon)  # Number of canonical eigenvalues
   axes <- Yhat.eig$u[,1:k]        # Canonical axes = f(X)
#
# A section could be added here to compute the RDA R-square (SS.Yhat/SS.Y) 
# and test its significance.
# A section could be added here to produce a biplot with scaling type 1 or 2.
#
# Test the significance of individual canonical axes
   #
   # No covariables: test canonical axis 1 by permutation of the raw data.
   # Test of axis 1: no residuals to be computed on previously tested axes
   F <- eig.values[1] / (SS.Y - SS.Yhat)
   Fstat <- F*(n-1-m)        # Start assembling vector 'Fstat'
   #
   set.seed(seed)
   nGE <- 1   # Hope correction: count ‘Fstat’ in the reference distribution
   for(iperm in 1:nperm) {
      Y.perm <- Y[sample(n),]
      SS.Y.perm <- SS.Y      # Same SS for Y and Y.perm after permuting Y rows
      # 
      # Re-use the qr.X: does not change during permutations
      Yhat.perm <- qr.fitted(qr.X, Y.perm)
      SS.Yhat.perm <- sum(Yhat.perm^2)
      Yhat.perm.eig <- svd(Yhat.perm, nv=0, nu=0)$d^2
      #
      F.perm <- Yhat.perm.eig[1] / (SS.Y.perm - SS.Yhat.perm)
      if(F.perm >= F) nGE <- nGE+1
      if(verbose) cat("Axis 1   :   F =",F,"  F.perm =",F.perm,'\n')
      }
   prob <- nGE/(nperm+1)     # Start assembling vector 'prob'
   
   # Test the following canonical axes by permuting residuals of reduced model
   if(k > 1) {
   for(j in 2:k) {
      # Compute the F statistic
      F <- eig.values[j] / (SS.Y - SS.Yhat)
      Fstat <- c(Fstat, F*(n-1-m))     # Attach the new F value to 'Fstat'
      #
      # Compute reduced model residuals of Y on the previously tested axes
      qr.prev  <- qr(axes[,1:(j-1)])
      Y.fit <- qr.fitted(qr.prev, Y)
      Y.res <- qr.resid(qr.prev, Y)
      #
      # Compute residuals of X on previously tested axes for partial RDA below
      qr.X.res <- qr(qr.resid(qr.prev, X))
      #   
      set.seed(seed)
      nGE <- 1   # Hope correction
      if(verbose) cat('\n')
      for(iperm in 1:nperm) {
         # Create permuted Y and compute its sum of squares (SS)
         Y.perm <- Y.fit + Y.res[sample(n),]
         SS.Y.perm <- sum(Y.perm^2)    # Not same SS as in the unpermuted data
         #
         # The j-th eigenvalue is the first eigenvalue of the partial RDA
         # of Y.perm by X residualized onthe previous axes[,1:(j-1)].
         # qr.X.res was computed before the permutation loop.
         Yhat.perm <- qr.fitted(qr.X.res, Y.perm)
         Yhat.perm.eig1 <- svd(Yhat.perm, nv=0, nu=0)$d[1]^2
         #
         # For denominator of the F-statistic: RDA of Y.perm on X.
         # qr.X was computed near the beginning of the function.
         YhatTot.perm <- qr.fitted(qr.X, Y.perm)
         SS.YhatTot.perm <- sum(YhatTot.perm^2)
         #
         # Compute the F-statistic under permutation for the tested eigenvalue
         F.perm <- Yhat.perm.eig1 / (SS.Y.perm - SS.YhatTot.perm)
         #
         if(F.perm >= F) nGE <- nGE+1
         if(verbose) cat("Axis [",j,"]:  F =",F,"  F.perm =",F.perm,'\n')
         }
      prob <- c(prob, nGE/(nperm+1))   # Attach the new probability to 'prob'
      }
      }
#
   })
   a[3] <- sprintf("%2f",a[3])
   cat("Computation time =",a[3]," sec",'\n')
#
# Output the  results
# The eigenvalues of the covariance matrix = (eigenvalues computed here)/(n-1)
out <- cbind(eig.values[1:k]/(n-1), Fstat, prob)
#
rownames(out) <- rownames(out, do.NULL=FALSE, prefix="Axis.")	
colnames(out) <- c("Eigenvalue", "F.marginal", "P.marginal")
out
}
